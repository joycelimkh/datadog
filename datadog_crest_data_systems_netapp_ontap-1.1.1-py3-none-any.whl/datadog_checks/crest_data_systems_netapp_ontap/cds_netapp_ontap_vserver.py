from .cds_netapp_ontap_utils import ingest_metric, instance_detail_query


class VServerIngestor:
    def __init__(self, instance_check) -> None:
        self.instance_check = instance_check
        self.client = instance_check.client
        self.host = instance_check.host
        self.log = instance_check.log

    def number_of_vserver(self, vserver_list):
        # set of vserver uuid for distinct count of vservers
        vserver_uuid = set()
        for vserver in vserver_list:
            vserver_uuid.add(vserver.get("uuid"))
        ingest_metric(
            self.instance_check,
            "dc_vserver_uuid",
            len(vserver_uuid),
        )

    def ingestor(self):
        try:
            results = {}
            if self.client.isClustered():
                results = self.client.queryApi(instance_detail_query("vserver-get-iter"))

            if not results.get("attributes-list"):
                self.log.info(
                    f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Nothing to ingest in 'VServer' details."  # noqa: G004
                )
                return

            vserver_list = results["attributes-list"].get("vserver-info") or []
            if isinstance(vserver_list, dict):
                vserver_list = [vserver_list]

            self.log.info(
                f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Fetched 'VServer' details of"  # noqa: G004
                " total '{instance_count}' instance(s).".format(instance_count=len(vserver_list))
            )

            self.number_of_vserver(vserver_list)
        except Exception:
            self.log.exception(
                f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Error occurred while ingesting"  # noqa: G004
                " 'VServer' Data."
            )
