from .cds_netapp_ontap_utils import ingest_metric, instance_detail_query


class ClusterIngestor:
    def __init__(self, instance_check) -> None:
        self.instance_check = instance_check
        self.client = instance_check.client
        self.host = instance_check.host
        self.log = instance_check.log

    def number_of_nodes(self, cluster_list):
        # set of cluster uuid for distinct count of clusters
        node_uuid = set()
        for cluster in cluster_list:
            node_uuid.add(cluster.get("node-uuid"))
        ingest_metric(
            self.instance_check,
            "dc_cluster_node_uuid",
            len(node_uuid),
        )

    def ingestor(self):
        try:
            results = {}
            if self.client.isClustered():
                results = self.client.queryApi(instance_detail_query("cluster-node-get-iter"))

            if not results.get("attributes-list"):
                self.log.info(
                    f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Nothing to ingest in 'Cluster' details."  # noqa: G004
                )
                return

            cluster_list = results["attributes-list"].get("cluster-node-info") or []
            if isinstance(cluster_list, dict):
                cluster_list = [cluster_list]

            self.log.info(
                f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Fetched 'Cluster' details of"  # noqa: G004
                " total '{instance_count}' instance(s).".format(instance_count=len(cluster_list))
            )

            self.number_of_nodes(cluster_list)
        except Exception:
            self.log.exception(
                f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Error occurred while ingesting"  # noqa: G004
                " 'Cluster' Data."
            )
