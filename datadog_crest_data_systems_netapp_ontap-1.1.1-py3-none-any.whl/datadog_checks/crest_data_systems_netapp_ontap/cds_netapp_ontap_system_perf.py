from .cds_netapp_ontap_perf import PerfHandler
from .cds_netapp_ontap_utils import ingest_metric, perf_response_parser


class SystemPerfIngestor:
    def __init__(self, instance_check) -> None:
        self.instance_check = instance_check
        self.client = instance_check.client
        self.host = instance_check.host
        self.log = instance_check.log

        self.perf_handler_obj = PerfHandler("System")

    def ingestor(self):
        # collect performance data
        try:
            responses = self.perf_handler_obj.collect(self.client)
            total_events = 0
            for response in responses:
                if response and response.get("@status") == "failed":
                    self.log.error(
                        f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Error occurred while collecting"  # noqa: G004
                        " 'System Performance' data. API request failed with error_code: '{error_code}'"
                        ' and reason: "{reason}"'.format(
                            error_code=response.get("@errno"), reason=response.get("@reason")
                        )
                    )
                    return
                elif not response or not response.get("instances"):
                    self.log.info(
                        f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Nothing to ingest in"  # noqa: G004
                        " 'System Performance' data."
                    )
                    return

                instances = response["instances"].get("instance-data", [])
                if isinstance(instances, dict):
                    instances = [instances]

                total_events += len(instances)

                for instance in instances:
                    event = perf_response_parser(instance.get("counters", {}).get("counter-data", []))
                    uuid = event.get("instance_uuid")
                    name = event.get("instance_name")
                    # ingest system details
                    ingest_metric(
                        self.instance_check,
                        "system.cpu_busy",
                        event.get("cpu_busy"),
                        [f"uuid:{uuid}", f"name:{name}"],
                    )

            self.log.info(
                f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Fetched 'System Performance' data of"  # noqa: G004
                " total '{instance_count}' instance(s).".format(instance_count=total_events)
            )
        except Exception:
            self.log.exception(
                f"NETAPP ONTAP | HOST={self.host} | MESSAGE=Error occurred while ingesting"  # noqa: G004
                " 'System Performance' Data."
            )
