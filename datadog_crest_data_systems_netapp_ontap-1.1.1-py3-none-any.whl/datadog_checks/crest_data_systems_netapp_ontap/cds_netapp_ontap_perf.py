from . import cds_netapp_ontap_constants as constants
from .NetApp.NaElement import NaElement


class PerfHandler:
    def __init__(self, object_name):
        self.object_name = object_name

    def collect(self, oc):
        """This method collects performance data of given object from server.

        RETURNS"""
        try:
            if oc.isClustered():
                perf_element = NaElement("perf-object-instance-list-info-iter")
            else:
                perf_element = NaElement("perf-object-instance-list-info")
            perf_element.child_add_string("objectname", self.object_name.lower())
            results = oc.queryApi(perf_element)

            if results.get("attributes-list"):
                instances = results["attributes-list"]
            elif results.get("instances"):
                instances = results["instances"]
            else:
                oc.log.info(
                    f"NETAPP ONTAP | HOST={oc.server} | MESSAGE=No instances are found"  # noqa: G004
                    f" of '{self.object_name}', while collecting '{self.object_name} Performance' data."
                )
                return

            # parse list of instances
            instances = instances.get("instance-info") or []
            if isinstance(instances, dict):
                instances = [instances]

            oc.log.info(
                f"NETAPP ONTAP | HOST={oc.server} | MESSAGE=Found '{len(instances)}'"  # noqa: G004
                f" instance(s) of '{self.object_name}', while fetching '{self.object_name} Performance' data."
            )

            batch_count = ((len(instances) - 1) // constants.MAX_INSTANCES_PERF) + 1
            for offset in range(batch_count):
                start = offset * constants.MAX_INSTANCES_PERF
                end = start + constants.MAX_INSTANCES_PERF

                # generate query to fetch instance's performance data
                perf_element = NaElement("perf-object-get-instances")
                perf_element.child_add_string("objectname", self.object_name.lower())

                instance_element = NaElement("instances")
                for instance in instances[start:end]:
                    instance_element.child_add_string("instance", instance.get("name"))
                perf_element.child_add(instance_element)

                oc.log.info(
                    f"NETAPP ONTAP | HOST={oc.server} | MESSAGE=Fetched '{self.object_name}"  # noqa: G004
                    " Performance' data of '{instance_count}' instances in batch of {start} to {end}.".format(
                        object_name=self.object_name, instance_count=len(instances[start:end]), start=start + 1, end=end
                    )
                )

                yield oc.queryApi(perf_element)
        except Exception:
            oc.log.exception(
                f"NETAPP ONTAP | HOST={oc.server} | MESSAGE=Error occurred while querying API to collect"  # noqa: G004
                " '{object_name} Performance' data.".format(object_name=self.object_name),
            )
