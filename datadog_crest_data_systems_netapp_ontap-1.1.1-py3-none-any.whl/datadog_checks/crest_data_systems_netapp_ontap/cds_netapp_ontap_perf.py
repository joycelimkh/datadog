from . import cds_netapp_ontap_constants as constants
from .NetApp.NaElement import NaElement


class PerfHandler:
    def __init__(self, object_name):
        self.object_name = object_name

    def collect(self, oc):
        """This method collects performance data of given object from server.

        RETURNS"""
        try:
            if oc.isClustered():
                perf_element = NaElement("perf-object-instance-list-info-iter")
            else:
                perf_element = NaElement("perf-object-instance-list-info")
            perf_element.child_add_string("objectname", self.object_name.lower())
            results = oc.queryApi(perf_element)

            if results.get("attributes-list"):
                instances = results["attributes-list"]
            elif results.get("instances"):
                instances = results["instances"]
            else:
                oc.log.info(
                    "NETAPP ONTAP INFO: No instances are found of '{object_name}',"  # noqa: G001
                    " while collecting '{object_name} Performance' data.".format(object_name=self.object_name),
                )
                return

            # parse list of instances
            instances = instances.get("instance-info") or []
            if isinstance(instances, dict):
                instances = [instances]

            oc.log.info(
                "NETAPP ONTAP INFO: Found '{instance_count}' instance(s) of '{object_name}',"  # noqa: G001
                " while fetching '{object_name} Performance' data.".format(
                    instance_count=len(instances), object_name=self.object_name
                )
            )

            batch_count = ((len(instances) - 1) // constants.MAX_INSTANCES) + 1
            for offset in range(batch_count):
                start = offset * constants.MAX_INSTANCES
                end = start + constants.MAX_INSTANCES

                # generate query to fetch instance's performance data
                perf_element = NaElement("perf-object-get-instances")
                perf_element.child_add_string("objectname", self.object_name.lower())

                instance_element = NaElement("instances")
                for instance in instances[start:end]:
                    instance_element.child_add_string("instance", instance.get("name"))
                perf_element.child_add(instance_element)

                oc.log.info(
                    "NETAPP ONTAP INFO: Fetched '{object_name} Performance' data of"  # noqa: G001
                    " '{instance_count}' instances in batch of {start} to {end}.".format(
                        object_name=self.object_name, instance_count=len(instances[start:end]), start=start + 1, end=end
                    )
                )

                yield oc.queryApi(perf_element)
        except Exception:
            oc.log.exception(
                "NETAPP ONTAP ERROR: Error occurred while querying API to collect"  # noqa: G001
                " '{object_name} Performance' data.".format(object_name=self.object_name),
            )
