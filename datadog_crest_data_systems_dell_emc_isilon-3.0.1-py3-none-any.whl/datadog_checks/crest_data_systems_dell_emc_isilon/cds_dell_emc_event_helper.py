"""Module for Event data"""
import time
from urllib.parse import urlencode

from . import cds_dell_emc_consts as constants
from . import cds_dell_emc_utils as utils


class CDSDellEMCEventHelper(object):
    """Class for Event data"""

    def __init__(self, instance):
        self.logs_service = "event_details"
        self.instance = instance

    def event_details(self, api):
        """Method to get Event data and ingest it as logs to Datadog platform."""
        # Get last event timestamp from Datadog
        last_event = self.instance.dd_client.get_checkpoint(self.logs_service)
        ts_field = api["panel_conf"]["timestamp_field"]
        if last_event.get(ts_field):
            self.instance.log.info(
                "Found event log in last 18 hours, hence collecting new events from last event's timestamp."
            )
            last_timestamp = int(last_event[ts_field]) + 1
        else:
            self.instance.log.info(
                "No event logs are collected in last 18 hours, hence collecting events of last 18 hours."
            )
            last_timestamp = int(time.time() - constants.CHECKPOINT_TIME_OFFSET)

        params = api.get("params", {})
        params["last_event_begin"] = last_timestamp
        url = f"{self.instance.base_uri}{api['api_url']}?{urlencode(params)}"
        event_count = 0
        self.instance.log.info("Fetching events data.")
        while True:
            response = self.instance._make_request(url)
            events = response.get("eventgroups", [])
            event_count += len(events)
            self.instance.log.info(f"Collected {len(events)} events so far.")  # noqa: G004
            self.ingest_events(events, api["panel_conf"])
            resume = response.get("resume")
            url = f"{self.instance.base_uri}{api['api_url']}?resume={resume}"
            if not resume:
                self.instance.log.info(f"Collected total {event_count} events.")  # noqa: G004
                break

    def ingest_events(self, event_data, panel_conf):
        """Method to ingest data to Datadog platform."""

        def evaluate_event_tags(event):
            log_data = utils.field_parser(
                event,
                panel_conf["log_fields"],
            )
            log_data["message"] = " | ".join([": ".join(causes) for causes in log_data.get("causes", [])])

            tag_data = utils.tag_generator(event, panel_conf["tag_fields"])
            return log_data, tag_data

        self.instance.dd_client.submit_logs(
            self.logs_service,
            utils.generate_logs(
                event_data,
                panel_conf["event_fields"],
                panel_conf["alias_fields"],
                panel_conf.get("conditions"),
            ),
            panel_conf.get("timestamp_field"),
            fn_to_evaluate_event=evaluate_event_tags,
        )
